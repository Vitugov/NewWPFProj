﻿namespace WPFUsefullThings
{
    [AttributeUsage(AttributeTargets.Class)]
    public class SubClassAttribute : Attribute {}
}
