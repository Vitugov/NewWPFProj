﻿namespace WPFUsefullThings
{
    [AttributeUsage(AttributeTargets.Property)]
    public class InvisibleAttribute : Attribute {}
}
